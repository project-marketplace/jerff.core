<?php

namespace Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Modules;

use Exception,
    Bitrix\Main\Application,
    Bitrix\Main\Loader,
    Bitrix\Main\ModuleManager;

class Utility {
    /* db */

    public function createDbTable($table) {
        if (!Application::getInstance()->getConnection()->isTableExists($table::getTableName())) {
            $table::getEntity()->createDbTable();
        }
    }

    public function dropTable($table) {
        Application::getInstance()->getConnection()->dropTable($table::getTableName());
    }

    public function RunSqlBatch($file) {
        global $DB;
        $DB->RunSQLBatch($this->dir . '/' . $file);
    }

    /* exception */

    public function ThrowException($message) {
        global $APPLICATION;
        $APPLICATION->ResetException();
        $APPLICATION->ThrowException($message);
    }

}
