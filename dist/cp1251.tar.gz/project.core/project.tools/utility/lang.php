<?php

namespace Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility;

use Bitrix\Main\Localization\Loc;

class Lang {

    static private $path = '';

    static public function init($path) {
        self::$path = dirname($path);
    }

    static public function load($path) {
        Loc::loadCustomMessages(str_replace(self::$path, self::$path . '/lang/' . LANG_ID, $path));
    }

}
