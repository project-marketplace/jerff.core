<?
$arModuleVersion = array(
	"VERSION" => "3.0.0",
	"VERSION_DATE" => "2018-04-26 19:31:24"
);
?>