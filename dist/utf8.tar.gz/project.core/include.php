<?php

include_once (__DIR__ . '/project.tools/include.php');

//Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Config::set(array(
//    /* Отладка */
//    'adminDebug' => [1],
//    'isDebug' => false,
//    /* Кеширование */
//    'isCache' => true,
//));
