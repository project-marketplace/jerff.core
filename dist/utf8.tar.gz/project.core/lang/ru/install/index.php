<?php

$MESS['JERFF_CORE_NAME'] = 'Модуль заготовка для битрикс маркеплейса';
$MESS['JERFF_CORE_DESCRIPTION'] = 'Можно использовать как образец';
$MESS['JERFF_AJAX_PARTNER_NAME'] = 'jerff';
$MESS['JERFF_AJAX_PARTNER_URI'] = 'https://jerff.ru';