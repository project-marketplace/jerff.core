<?php

$MESS['JERFF_CORE_NAME'] = 'Модуль заготовка для битрикс маркетплейса';
$MESS['JERFF_CORE_DESCRIPTION'] = 'Можно использовать как образец, или модуль заготовка';
$MESS['JERFF_AJAX_PARTNER_NAME'] = 'jerff';
$MESS['JERFF_AJAX_PARTNER_URI'] = 'https://jerff.ru';