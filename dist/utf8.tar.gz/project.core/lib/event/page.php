<?

namespace Project\Core\Event;

class Page {

    public static function OnPageStart() {
        /*
         * подлючаем модуль для сайта
         */
    }

}
