<?

namespace Jerff\Core\Event;

class Page {

    public static function OnPageStart() {
        /*
         * подлючаем модуль для сайта
         */
    }

}
