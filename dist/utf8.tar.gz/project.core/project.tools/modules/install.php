<?php

namespace Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Modules;

include_once(__DIR__ . '/utility.php');

const IS_START = true;

use Exception,
    Bitrix\Main\Application,
    Bitrix\Main\Loader,
    Bitrix\Main\ModuleManager,
    Bitrix\Main\EventManager,
    Bitrix\Main\Localization\Loc,
    Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Lang;

Lang::load(__FILE__);

trait Install {

    private $dir = '';
    private $message = '';

    protected function setParam($dir, $message) {
        $this->dir = $dir;
        $this->message = $message;
        include($this->dir . '/version.php');
        if (is_array($arModuleVersion) && array_key_exists('VERSION', $arModuleVersion)) {
            $this->MODULE_VERSION = $arModuleVersion['VERSION'];
            $this->MODULE_VERSION_DATE = $arModuleVersion['VERSION_DATE'];
        }
    }

    /* message */

    public function getMessage($message, $data = array()) {
        return Loc::getMessage($this->message . '_' . $message, $data) ?: Loc::getMessage('Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools_' . $message, $data);
    }

    public function Install() {
        Application::getConnection()->startTransaction();
        ModuleManager::registerModule($this->MODULE_ID);
        Loader::includeModule($this->MODULE_ID);
        try {
            $this->InstallDB();
        } catch (Exception $e) {
            Application::getConnection()->rollbackTransaction();
            ModuleManager::unRegisterModule($this->MODULE_ID);
            return Utility::ThrowException($this->getMessage('INSTALL_DB_ERROR', array(
                                'ERROR' => $e->getMessage()
            )));
        }
        try {
            $this->InstallFiles();
        } catch (Exception $e) {
            Application::getConnection()->rollbackTransaction();
            ModuleManager::unRegisterModule($this->MODULE_ID);
            return Utility::ThrowException($this->getMessage('INSTALL_FILES_ERROR', array(
                                'ERROR' => $e->getMessage()
            )));
        }
        $this->InstallEvent();
        $this->InstallAgent();
        Application::getConnection()->commitTransaction();
    }

    public function Uninstall() {
        Application::getConnection()->startTransaction();
        Loader::includeModule($this->MODULE_ID);
        try {
            $this->UnInstallDB();
        } catch (Exception $e) {
            Application::getConnection()->rollbackTransaction();
            return Utility::ThrowException($this->getMessage('UNINSTALL_DB_ERROR', array(
                                'ERROR' => $e->getMessage()
            )));
        }
        try {
            $this->UnInstallFiles();
        } catch (Exception $e) {
            Application::getConnection()->rollbackTransaction();
            return Utility::ThrowException($this->getMessage('UNINSTALL_FILES_ERROR', array(
                                'ERROR' => $e->getMessage()
            )));
        }
        $this->UnInstallEvent();
        $this->UnInstallAgent();
        ModuleManager::unRegisterModule($this->MODULE_ID);
        Application::getConnection()->commitTransaction();
    }

    /*
     * InstallEvent
     */

    public function registerEventHandler($modul, $event, $class, $func) {
        EventManager::getInstance()->registerEventHandler($modul, $event, $this->MODULE_ID, $class, $func);
    }

    public function unRegisterEventHandler($modul, $event, $class, $func) {
        EventManager::getInstance()->unRegisterEventHandler($modul, $event, $this->MODULE_ID, $class, $func);
    }

    public function InstallEvent() {

    }

    public function UnInstallEvent() {

    }

    /*
     * InstallDB
     */

    public function InstallDB() {

    }

    public function UnInstallDB() {

    }

    /*
     * InstallFiles
     */

    public function InstallFiles() {

    }

    public function UnInstallFiles() {

    }

    /*
     * InstallAgent
     */

    public function InstallAgent() {
//        Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Utility\Agent::add(
//                '\Tm\Portal\Agent\Tasks::process();', // имя функции
//                $this->moduleId, // идентификатор модуля
//                "N", // агент не критичен к кол-ву запусков
//                30 * 60, // интервал запуска - 1 сутки
//                "", // дата первой проверки - текущее
//                "N", // агент активен
//                "", // дата первого запуска - текущее
//                30);
    }

    public function UnInstallAgent() {
//        CAgent::RemoveAgent('\Tm\Portal\Agent\Tasks::process();', $this->moduleId);
    }

}
