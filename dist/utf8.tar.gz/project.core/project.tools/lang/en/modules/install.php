<?php

$MESS['Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools_INSTALL_DB_ERROR'] = 'An error occurs during database installation. ERROR';
$MESS['Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools_UNINSTALL_DB_ERROR'] = 'An error occurs during database uninstallation. ERROR';
$MESS['Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools_INSTALL_FILES_ERROR'] = 'An error occurs during midule files installation. ERROR';
$MESS['Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools_UNINSTALL_FILES_ERROR'] = 'An error occurs during midule files uninstallation. ERROR';
