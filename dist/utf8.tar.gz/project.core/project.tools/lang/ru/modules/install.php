<?php

$MESS['Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools_INSTALL_DB_ERROR'] = 'Произошла ошибка в процессе инсталляции БД модуля. ERROR';
$MESS['Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools_UNINSTALL_DB_ERROR'] = 'Произошла ошибка в процессе деинсталляции БД модуля. ERROR';
$MESS['Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools_INSTALL_FILES_ERROR'] = 'Произошла ошибка в процессе инсталляции файлов модуля. ERROR';
$MESS['Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools_UNINSTALL_FILES_ERROR'] = 'Произошла ошибка в процессе деинсталляции файлов модуля. ERROR';