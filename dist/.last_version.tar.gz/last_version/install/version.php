<?
$arModuleVersion = array(
	"VERSION" => "2.0.0",
	"VERSION_DATE" => "2018-02-04 13:30:53"
);
?>