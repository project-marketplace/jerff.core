<?

$eventManager = Bitrix\Main\EventManager::getInstance();
//$eventManager->addEventHandler('main', 'OnEpilog', array('\Jerff\Core\Event\Page', 'OnEpilog'));
