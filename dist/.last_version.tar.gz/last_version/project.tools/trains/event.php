<?

namespace Project\Ver276ebf5263b8384672761a9eef2eef22432e2e68\Tools\Trains;

use Exception;

trait Event {

    static private $isStart = array();

    static protected function evetType() {
        throw new Exception('���������� ��� �������');
    }

    static protected function start() {
        if (empty(self::$isStart[static::evetType()])) {
            self::$isStart[static::evetType()] = true;
            return true;
        } else {
            return false;
        }
    }

    static protected function stop() {
        unset(self::$isStart[static::evetType()]);
        return false;
    }

}
